import React,{ useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';

export function EditMovie(props) {

    let { id } = useParams();

    const [title, setTitle] = useState("1");
    const [cover, setCover] = useState("");

    const [isLoading, setLoading] = useState(true);

    const navigate = useNavigate();

    useEffect(() => {
       
        axios.get("http://localhost:2000/api/movies/" + id)
            .then((response) => {
               
                setLoading(false);

                setTitle(response.data.title);
                setCover(response.data.cover);
            })
            .catch(function (error) {
                console.log(error);
            })
    }, []);

    if(isLoading){
        return(<div>Retrieving Data.....</div>);
    }

    const submitMovie = (event) => {
        event.preventDefault();

        
        const changeMovie = {
            id: id,
            title: title,
            cover: cover,
        };

        //Save
        axios.put("http://localhost:2000/api/songs/" + id, changeMovie)
            .then((res) => {
                console.log(res.data);
                navigate('/readMovies');
            });
    }

    //Output
    return (
        <div>
                {/* Print to screen */}
                <h1>Change change movie info</h1>
                <br></br>

                {/* Form to Add Movie to Array */}
                <form onSubmit={submitSong}>
                    {/* Title */}
                    <div className="form-group">
                        <label htmlFor="title" className="title">Movie Title: </label>
                        <input  id="title" type="text" value={title} onChange={(e) => setTitle(e.target.value)} required />
                    </div>

                    {/* Cover */}
                    <div className="form-group">
                        <label htmlFor="cover" className="cover">Movie Cover: </label>
                        <input id="cover" type="text" value={cover} onChange={(e) => setCover(e.target.value)} required />
                    </div>

                    {/* Submit Button */}
                    <br></br>
                    <input className="submit" type="submit" value="Edit Movie" />
                </form>
            </div>
    );
}