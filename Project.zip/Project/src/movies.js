import React from "react";
import { MovieList } from './movieList';

export class Movies extends React.Component {
    render() {
        return this.props.movies.map(
            (movie) => {
                return <MovieList movie={movie} key={movie._id} ></MovieList>
            }
        );
    }
}