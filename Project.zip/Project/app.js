//CSS
import 'bootstrap/dist/css/bootstrap.min.css'; //NavBar
import './App.css';

//React
import React from 'react';

//Navbar
import Navbar from 'react-bootstrap/Navbar';
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';

//Components
import { AddMovie } from './components/addMovie';
import { ReadMovie } from './components/readMovie';
import { EditMovie } from './components/editMovie';

//Router
import {
  BrowserRouter as Router,
  Routes, Route
} from 'react-router-dom';

//Class
class App extends React.Component {
  
  render() {
    return (
      <Router>
        <div className="App">
          <Navbar bg="primary" variant="dark">
            <Container>
              <Navbar.Brand href="/">Movie Collection</Navbar.Brand>
              <Nav className="me-auto">
                <Nav.Link href="/readMovie">Home</Nav.Link>
                <Nav.Link href="/addMovie">Add Movie</Nav.Link>
              </Nav>
            </Container>
          </Navbar>

          <Routes>
            <Route path='/' element={<ReadMovie></ReadMovie>}></Route>
            <Route path='/readMovie' element={<ReadMovie></ReadMovie>}></Route>
            <Route path='/addMovie' element={<AddMovie></AddMovie>}></Route>
            <Route path="/editSong/:id" element={<EditMovie></EditMovie>}></Route>
          </Routes>
        </div>
      </Router>
    );
  }
}

//Export
export default App;