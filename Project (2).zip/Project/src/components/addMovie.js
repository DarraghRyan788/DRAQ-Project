//Imports
import axios from "axios";
import React from "react";

export class AddMovie extends React.Component {
    //Constructor
    constructor() {
        super();

        //Bind to Event
        this.submitMovie = this.submitMovie.bind(this);

        this.onChangeTitle = this.onChangeTitle.bind(this);
        this.onChangeCover = this.onChangeCover.bind(this);

        //Set Value to blank
        this.state = {
            title: '',
            cover: '',
        }
    }

    //Submit
    submitMovie(e) {
        e.preventDefault();

        //Print to Console
        console.log(`Button Clicked!\nTitle: ${this.state.title}\nCover: ${this.state.cover}`);

        const movies = {
            title: this.state.title,
            cover: this.state.cover,
        }

        //Generate HTTP Request 
        axios.post("http://localhost:2000/api/songs", movies)
            .then(console.log("HTTP Request Sent"))
            .catch((error) => {
                console.log(error)
            });

        //Reset to blank
        this.setState({
            title: '',
            cover: '',
        })
    }

    //Change Title
    onChangeTitle(e) {
        this.setState({
            title: e.target.value
        })
    }

    //Change Cover
    onChangeCover(e) {
        this.setState({
            cover: e.target.value
        })
    }

    render() {
        return (
            //Print to Screen
            <div>
                {/* Print to screen */}
                <h2>Add New movie info</h2>
                <br></br>

                {/* Form to Add Movie to Array */}
                <form onSubmit={this.submitSong}>
                    {/* Title */}
                    <div className="form-group">
                        <label htmlFor="title" className="title">Movie Title: </label>
                        <input id="title" type="text" value={this.state.title} onChange={this.onChangeTitle} required />
                    </div>

                    {/* Cover */}
                    <div className="form-group">
                        <label htmlFor="cover" className="cover">Movie Cover: </label>
                        <input id="cover" type="text" value={this.state.movie} onChange={this.onChangeCover} required />
                    </div>

                    {/* Submit Button */}
                    <br></br>
                    <input className="submit" type="submit" value="Add Movie" />
                </form>
            </div>
        )
    }
}