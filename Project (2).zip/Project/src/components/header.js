import React  from "react";

export class Header extends React.Component{
    render(){
        return(
            <div>
                <h1>My header component</h1>
            </div>
        );
    }
}