
import React from "react";
import axios from "axios";


import { Movies } from "./movies";

export class ReadMovie extends React.Component {
    
    constructor() {
        super();

       
        this.reload = this.reload.bind(this);
    }

    
    reload() {
        this.componentDidMount();
    }

   
    componentDidMount() {
        
        axios.get('http://localhost:2000/api/movies')
            
            .then((response) => {
                
                this.setState({ movies: response.data });
            }
            )
            
            .catch(
                (error) => {
                    console.log(error);
                });
    }

    
    state = {
        
        movies: []
    }

    render() {
        return (
            <div className="App">
                <center>
                    <h3>List of Movies</h3>
                    <Movies movies={this.state.movies} reload={this.reload}></Movies>
                </center>
            </div>
        )
    }
}