import React from "react";

export class Footer extends React.Component{

    render(){
        return(
            <div>
                <h1>My Footer component</h1>
            </div>
        );
    }
}