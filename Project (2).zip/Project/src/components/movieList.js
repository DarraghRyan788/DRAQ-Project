
import React from "react";
import Card from 'react-bootstrap/Card';
import Button from "react-bootstrap/Button";
import { Link } from "react-router-dom";
import axios from "axios";

export class MovieList extends React.Component {
    
    constructor() {
        super();
        
        this.DeleteMovie = this.DeleteMovie.bind(this);
    }

    
    DeleteMovie(e) {
        e.preventDefault();
        axios.delete('http://localhost:2000/api/movie/' + this.props.movie._id)
            .then((res) => { this.props.Reload(); })
            .catch();
    }

    
    render() {
        return (
            <div className="SongItem">
                <center>
                    <Card style={{ width: '80%' }}>
                        <Card.Header>
                            <Card.Title>{this.props.movie.title}</Card.Title>
                        </Card.Header>

                        <Card.Body>
                            <Card.Img src={this.props.movie.cover} style={{ width: "200px" }}/>
                        </Card.Body>

                        <Card.Footer>
                            <Link to={'/editMovie/:' + this.props.movie._id} className="btn btn-primary">Edit</Link>

                            <Button variant="danger" onClick={this.DeleteMovie} style={{ margin: "10px" }}>Delete</Button>
                        </Card.Footer>
                    </Card>
                </center>
            </div>
        )
    }
}